<p align="center">
  <img src="https://telegra.ph/file/5f300db034fe1c137d295.jpg">
</p>


[![Codacy Badge](https://api.codacy.com/project/badge/Grade/f7c51539e67b483bb8d7749acca51d3a)](https://app.codacy.com/gh/dangerousjatt/SpamBot-2.0?utm_source=github.com&utm_medium=referral&utm_content=dangerousjatt/SpamBot-2.0&utm_campaign=Badge_Grade_Settings)
[![Size](https://img.shields.io/github/repo-size/dangerousjatt/SpamBot-2.0?style=flat-square&color=green)](https://github.com/dangerousjatt/SpamBot-2.0/)   
[![Python](https://img.shields.io/badge/Python-v3.9-blue)](https://www.python.org/)
[![Maintenance](https://img.shields.io/badge/Maintained%3F-yes-green.svg)](https://github.com/dangerousjatt/SpamBot-2.0/graphs/commit-activity)
[![Open Source Love svg2](https://badges.frapsoft.com/os/v2/open-source.svg?v=103)](https://github.com/dangerousjatt/SpamBot-2.0)   
[![Contributors](https://img.shields.io/github/contributors/dangerousjatt/SpamBot-2.0?style=flat-square&color=green)](https://github.com/dangerousjatt/SpamBot-2.0/graphs/contributors)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg?style=flat-square)](https://makeapullrequest.com)
[![License](https://img.shields.io/badge/License-AGPL-blue)](https://github.com/dangerousjatt/SpamBot-2.0/blob/main/LICENSE)

----

## 𝚂𝚃𝙰𝚃𝚄𝚂 𝙾𝙵 𝚃𝙷𝙸𝚂 𝙱𝙾𝚃 
<p align="left"><a href="https://github.com/dangerousjatt/SpamBot-2.0/network/members"><img src="https://img.shields.io/github/forks/dangerousjatt/SpamBot-2.0?label=Forks&logoColor=Black&style=social"></a><p align="left"><a href="https://github.com/dangerousjatt/SpamBot-2.0/stargazers"><img src="https://img.shields.io/github/stars/dangerousjatt/SpamBot-2.0?logoColor=Blue&style=social"></a><p align="left"><a href="https://github.com/dangerousjatt/SpamBot-2.0"></a><p align="left"><a href="https://github.com/dangerousjatt/SpamBot-2.0?"><img src="https://img.shields.io/github/last-commit/dangerousjatt/SpamBot-2.0?style=plastic"></

-------------------------------------------------

## 𝚂𝚄𝙿𝙿𝙾𝚁𝚃 
                          
<a href="https://t.me/deadly_spam_bot"><img src="https://img.shields.io/badge/Join-SUPPORT%20GROUP-red.svg?logo=Telegram"></a>
<a href="https://t.me/deadly_spammer"><img src="https://img.shields.io/badge/Join-SUPPORT%20CHANNEL-red.svg?logo=Telegram"></a>

-------------------------------------------------
## 𝙾𝚆𝙽𝙴𝚁 -[𝚂𝙰𝙼𝙴𝙴𝚁🇮🇳](https://t.me/OFFICIAL_SAMEER)
## 𝙲𝙾 𝙾𝚆𝙽𝙴𝚁 -[𝙳𝙰𝙽𝙸𝚂𝙷🇮🇳](https://t.me/IDANISHBAABA)
## 𝙲𝚁𝙴𝙰𝚃𝙾𝚁 -[𝚄𝚂𝚃𝙰𝙳🇮🇳](https://t.me/USTAD_OP)
-------------------------------------------------

## 🚀 Deploy on Heroku 
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/DEADLY-FIGHTERS/DEADLY-SPAM-BOT-2.0)
------------------------------------------------

